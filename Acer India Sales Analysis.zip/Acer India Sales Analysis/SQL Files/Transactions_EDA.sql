select * from transactions;

-- Time-Based Analysis --
-- Yearly Sales Trend
-- Is there a noticeable growth or decline in sales over time
SELECT 
    YEAR(STR_TO_DATE(order_date, '%Y-%m-%d')) AS sales_year,
    SUM(sales_amount) AS total_revenue
FROM transactions
WHERE sales_amount != -1
GROUP BY sales_year
ORDER BY sales_year;

-- Monthly Sales Trend Across All Years 
SELECT 
    MONTHNAME(STR_TO_DATE(order_date, '%Y-%m-%d')) AS month_name,
    MONTH(STR_TO_DATE(order_date, '%Y-%m-%d')) AS month_number,
    SUM(sales_amount) AS total_revenue
FROM transactions
WHERE sales_amount != -1
GROUP BY month_number, month_name
ORDER BY month_number;

-- Which year had the highest total sales revenue
SELECT 
    YEAR(STR_TO_DATE(order_date, '%Y-%m-%d')) AS sales_year,
    SUM(sales_amount) AS total_revenue
FROM transactions
WHERE sales_amount != -1
GROUP BY sales_year
ORDER BY total_revenue DESC
LIMIT 1;

-- Product-Level Analysis --
-- Which are the top 5 products by revenue
SELECT 
    product_code,
    SUM(sales_amount) AS total_revenue
FROM transactions
WHERE sales_amount != -1
GROUP BY product_code
ORDER BY total_revenue DESC
LIMIT 5;

-- Which products have the highest sales quantity but low revenue
SELECT 
    product_code,
    SUM(sales_qty) AS total_quantity,
    SUM(sales_amount) AS total_revenue,
    ROUND(SUM(sales_amount) / NULLIF(SUM(sales_qty), 0), 2) AS avg_unit_price
FROM transactions
WHERE sales_amount != -1
GROUP BY product_code
ORDER BY total_quantity DESC
LIMIT 10;

-- Are there products with declining popularity over the years
SELECT 
    YEAR(STR_TO_DATE(order_date, '%Y-%m-%d')) AS sales_year,
    product_code,
    SUM(sales_qty) AS total_quantity
FROM transactions
WHERE sales_amount != -1
GROUP BY sales_year, product_code
ORDER BY product_code, sales_year;

-- Market/Region Analysis --
-- Which market/region (market_code) generates the highest revenue
SELECT 
    market_code,
    SUM(sales_amount) AS total_revenue
FROM transactions
WHERE sales_amount != -1
GROUP BY market_code
ORDER BY total_revenue DESC
LIMIT 1;

-- Is there a market where sales are consistently increasing or decreasing
SELECT 
    YEAR(STR_TO_DATE(order_date, '%Y-%m-%d')) AS sales_year,
    market_code,
    SUM(sales_amount) AS total_revenue
FROM transactions
WHERE sales_amount != -1
GROUP BY market_code, sales_year
ORDER BY  market_code, sales_year
;

-- Are some markets specializing in specific products
SELECT 
    market_code,
    product_code,
    COUNT(*) AS transaction_count,
    SUM(sales_qty) AS total_quantity,
    SUM(sales_amount) AS total_revenue
FROM transactions
WHERE sales_amount != -1
GROUP BY market_code, product_code
ORDER BY market_code, total_quantity DESC;


-- Customer Analysis --
-- Who are the top 5 customers by total purchase amount
SELECT 
    customer_code,
    SUM(sales_amount) AS total_revenue
FROM transactions
WHERE sales_amount != -1
GROUP BY customer_code
ORDER BY total_revenue DESC
LIMIT 5;

-- Are there any inactive or low-frequency customers
SELECT 
    customer_code,
    COUNT(*) AS total_transactions,
    SUM(sales_amount) AS total_revenue
FROM transactions
WHERE sales_amount != -1
GROUP BY customer_code
ORDER BY total_transactions ASC, total_revenue ASC
LIMIT 10;

-- Do different customers prefer different products or markets 
SELECT 
    customer_code,
    product_code,
    COUNT(*) AS purchase_count,
    SUM(sales_qty) AS total_quantity,
    SUM(sales_amount) AS total_spent
FROM transactions
WHERE sales_amount != -1
GROUP BY customer_code, product_code
ORDER BY customer_code, total_quantity DESC;

-- Sales Quality & Exceptions -- 
-- 13.	Are there any missing or negative sales entries? How frequent are they
SELECT 
    COUNT(*) AS invalid_entries
FROM transactions
-- WHERE sales_amount = -1 OR sales_amount = 0;
WHERE sales_amount = -1 and sales_amount = 0;

-- What is the average sales amount per transaction
SELECT 
    ROUND(AVG(sales_amount), 2) AS avg_sales_amount
FROM transactions
WHERE sales_amount != -1;

-- What is the average order quantity per product
SELECT 
    product_code,
    ROUND(AVG(sales_qty), 2) AS avg_order_quantity
FROM transactions
GROUP BY product_code
ORDER BY avg_order_quantity DESC;













