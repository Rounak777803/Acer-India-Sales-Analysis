-- Data Profiling --
-- What is the total number of products and their distribution by product type --
SELECT 
    product_type, 
    COUNT(*) AS product_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM products), 2) AS percentage
FROM products
GROUP BY product_type;

-- What are the range and count of product codes
SELECT 
    MIN(product_code) AS min_code,
    MAX(product_code) AS max_code,
    COUNT(*) AS total_products
FROM products;

-- Data Quality Checks --
-- Are there any duplicate product codes
SELECT product_code, COUNT(*) AS count
FROM products
GROUP BY product_code
HAVING count > 1;

-- Are there any missing or null values in the dataset
SELECT 
    COUNT(*) AS total_records,
    SUM(CASE WHEN product_code IS NULL THEN 1 ELSE 0 END) AS null_codes,
    SUM(CASE WHEN product_type IS NULL THEN 1 ELSE 0 END) AS null_types
FROM products;


-- Preparation for Time-Based and Relational Analysis --
-- How can I prepare a product-date combination for future sales analysis
SELECT 
    p.product_code, 
    p.product_type, 
    d.date, 
    d.date_yy_mmm
FROM products p
CROSS JOIN date d
WHERE d.date BETWEEN '2019-01-01' AND '2019-12-31'
LIMIT 10;

-- How many product-date combinations exist by product type and year
SELECT 
    p.product_type, 
    d.year, 
    COUNT(*) AS combination_count
FROM products p
CROSS JOIN date d
GROUP BY p.product_type, d.year
ORDER BY d.year, p.product_type;

-- How can I create a comprehensive customer-market-product-date framework
SELECT 
    c.customer_code, 
    c.custmer_name, 
    c.customer_type, 
    m.markets_code, 
    m.markets_name, 
    m.zone, 
    p.product_code, 
    p.product_type, 
    d.date, 
    d.date_yy_mmm
FROM customers c
CROSS JOIN markets m
CROSS JOIN products p
CROSS JOIN date d
WHERE d.date BETWEEN '2019-06-01' AND '2019-06-30'
LIMIT 10;

-- Business-Relevant Insights --
-- Which product type dominates the portfolio, and what does this suggest for inventory strategy
SELECT 
    product_type, 
    COUNT(*) AS product_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM products), 2) AS percentage
FROM products
GROUP BY product_type
ORDER BY product_count DESC;

-- How can I identify the first and last product codes for each product type
SELECT 
    product_type,
    MIN(product_code) AS first_code,
    MAX(product_code) AS last_code
FROM products
GROUP BY product_type;

