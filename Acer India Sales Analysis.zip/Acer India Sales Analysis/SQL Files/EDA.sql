-- Summary Statistics --
-- What are the total number of transactions, average sales amount, and total sales value (in INR, converting USD at 1 USD = 83 INR) across all datasets
WITH SummaryStats AS (
    SELECT 
        COUNT(*) as total_transactions,
        round(AVG(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END),2) as avg_sales_amount,
        SUM(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END) as total_sales_inr
    FROM transactions
    WHERE sales_amount > 0
)
SELECT * FROM SummaryStats;


-- Product Analysis --
-- Which products (product_code) generate the highest total sales amount and average sales per transaction across all datasets\
WITH ProductStats AS (
    SELECT 
        product_code,
        SUM(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END) as total_sales,
        round(AVG(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END),2) as avg_sales,
        ROW_NUMBER() OVER (ORDER BY SUM(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END) DESC) as total_rank,
        ROW_NUMBER() OVER (ORDER BY AVG(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END) DESC) as avg_rank
    FROM transactions
    WHERE sales_amount > 0
    GROUP BY product_code
)
SELECT product_code, total_sales, avg_sales
FROM ProductStats
WHERE total_rank = 1 OR avg_rank = 1;


-- Customer Behavior --
-- Which customers (customer_code) contribute the most to total sales, and are there any customers with unusual transaction patterns
WITH CustomerStats AS (
    SELECT 
        customer_code,
        SUM(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END) as total_sales,
        MIN(sales_amount) as min_sale,
        MAX(sales_amount) as max_sale
    FROM transactions
    WHERE sales_amount > 0
    GROUP BY customer_code
)
SELECT customer_code, total_sales, min_sale, max_sale
FROM CustomerStats
ORDER BY total_sales DESC
LIMIT 1;

-- Market Distribution --
-- How is sales distributed across different markets (market_code), and which market has the highest average transaction value
WITH MarketStats AS (
    SELECT 
        market_code,
        SUM(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END) as total_sales,
        AVG(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END) as avg_sale
    FROM transactions
    WHERE sales_amount > 0
    GROUP BY market_code
)
SELECT market_code, total_sales, avg_sale
FROM MarketStats
ORDER BY avg_sale DESC
LIMIT 1;

-- Sales Anomalies --
-- Are there any significant outliers or spikes in sales amounts across the combined data, and what might explain them


-- Currency Impact --
-- How does the presence of USD transactions affect the overall sales distribution, and what is the conversion impact on total revenue
WITH CurrencyImpact AS (
    SELECT 
        currency,
        SUM(sales_amount) as raw_total,
        SUM(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END) as converted_total
    FROM transactions
    WHERE sales_amount > 0
    GROUP BY currency
)
SELECT 
    SUM(raw_total) as total_without_conversion,
    SUM(converted_total) as total_with_conversion,
    (SUM(converted_total) - SUM(raw_total)) / SUM(raw_total) * 100 as percent_increase
FROM CurrencyImpact;


-- Seasonality --
-- Do sales show seasonal patterns (e.g., higher sales in certain months) when aggregating all datasets, and can we correlate these with specific products or customers
WITH MonthlySales AS (
    SELECT 
        MONTH(order_date) AS month,
        SUM(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END) AS monthly_total,
        GROUP_CONCAT(CONCAT(product_code, ' (', customer_code, ')') SEPARATOR ', ') AS top_products
    FROM transactions
    WHERE sales_amount > 0
    GROUP BY MONTH(order_date)
)
SELECT month, monthly_total, top_products
FROM MonthlySales
ORDER BY monthly_total DESC
LIMIT 2;

-- Transaction Frequency --
-- What is the distribution of sales quantities (sales_qty) across transactions, and are there products with consistently high or low order volumes
WITH QuantityDistribution AS (
    SELECT 
        CASE 
            WHEN sales_qty BETWEEN 1 AND 10 THEN '1-10'
            WHEN sales_qty BETWEEN 11 AND 100 THEN '11-100'
            ELSE '>100' 
        END as qty_range,
        COUNT(*) as freq,
        AVG(sales_qty) as avg_qty
    FROM transactions
    WHERE sales_amount > 0
    GROUP BY CASE 
                WHEN sales_qty BETWEEN 1 AND 10 THEN '1-10'
                WHEN sales_qty BETWEEN 11 AND 100 THEN '11-100'
                ELSE '>100' 
            END
)
SELECT qty_range, freq, avg_qty FROM QuantityDistribution;


-- Based on the combined data, which areas (e.g., specific products, customers, or time periods) warrant deeper investigation for business strategy 
WITH KeyAreas AS (
    SELECT 'Product' as category, product_code as focus, SUM(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END) as metric
    FROM transactions WHERE sales_amount > 0 GROUP BY product_code
    UNION ALL
    SELECT 'Customer' as category, customer_code as focus, SUM(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END) as metric
    FROM transactions WHERE sales_amount > 0 GROUP BY customer_code
    UNION ALL
    SELECT 'Month' as category, DATE_FORMAT(order_date, '%Y-%m') as focus, SUM(CASE WHEN currency = 'USD' THEN sales_amount * 83 ELSE sales_amount END) as metric
    FROM transactions WHERE sales_amount > 0 GROUP BY DATE_FORMAT(order_date, '%Y-%m')
)
SELECT category, focus, metric
FROM KeyAreas
ORDER BY metric DESC
LIMIT 3;