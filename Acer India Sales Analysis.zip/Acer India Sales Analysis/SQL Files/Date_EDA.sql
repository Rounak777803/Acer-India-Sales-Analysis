-- Data Profiling --
-- What is the date range and total number of records in the dataset
SELECT 
    MIN(date) AS earliest_date,
    MAX(date) AS latest_date,
    COUNT(*) AS total_records,
    DATEDIFF(MAX(date), MIN(date)) + 1 AS total_days
FROM date;

-- How many records exist per year and month
SELECT 
    year, 
    month_name, 
    COUNT(*) AS record_count
FROM date
GROUP BY year, month_name
ORDER BY year, FIELD(month_name, 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');

-- How many unique values are there in each column 
SELECT 
    COUNT(DISTINCT date) AS unique_dates,
    COUNT(DISTINCT cy_date) AS unique_cy_dates,
    COUNT(DISTINCT year) AS unique_years,
    COUNT(DISTINCT month_name) AS unique_months,
    COUNT(DISTINCT date_yy_mmm) AS unique_yy_mmm
FROM date;


-- Data Quality Checks -- 
-- Are there any missing or null values in the dataset
SELECT 
    SUM(CASE WHEN date IS NULL THEN 1 ELSE 0 END) AS null_date,
    SUM(CASE WHEN cy_date IS NULL THEN 1 ELSE 0 END) AS null_cy_date,
    SUM(CASE WHEN year IS NULL THEN 1 ELSE 0 END) AS null_year,
    SUM(CASE WHEN month_name IS NULL THEN 1 ELSE 0 END) AS null_month_name,
    SUM(CASE WHEN date_yy_mmm IS NULL THEN 1 ELSE 0 END) AS null_date_yy_mmm
FROM date;


-- Are the derived columns (cy_date, year, month_name, date_yy_mmm) consistent with the date column
SELECT date, cy_date, year, month_name, date_yy_mmm
FROM date
WHERE 
    cy_date != DATE_FORMAT(date, '%Y-%m-01')
    OR year != YEAR(date)
    OR month_name != MONTHNAME(date)
    OR date_yy_mmm != CONCAT(SUBSTRING(YEAR(date), 3, 2), '-', LEFT(MONTHNAME(date), 3));
    
    
-- Are there any duplicate dates
SELECT date, COUNT(*) AS count
FROM date
GROUP BY date
HAVING count > 1;


-- Preparation for Time-Based Analysis
-- How many days are in each year, and does it account for leap years
SELECT 
    year, 
    COUNT(*) AS day_count,
    CASE 
        WHEN COUNT(*) = 366 THEN 'Leap Year'
        ELSE 'Non-Leap Year'
    END AS leap_year_status
FROM date
GROUP BY year
ORDER BY year;

-- What are the distinct month-year combinations available for analysis 
SELECT DISTINCT date_yy_mmm
FROM date
ORDER BY date_yy_mmm;

-- How can I create a quarter column for seasonal analysis
SELECT 
    date, 
    year, 
    month_name, 
    QUARTER(date) AS quarter,
    CONCAT('Q', QUARTER(date), '-', year) AS quarter_year
FROM date
LIMIT 10;

-- Business-Relevant Insights --
-- Which months have the most days, and how might this impact sales analysis
SELECT 
    month_name, 
    COUNT(*) AS day_count
FROM date
GROUP BY month_name
ORDER BY day_count DESC;

-- How can I identify key holiday periods for potential sales spikes
SELECT 
    date, 
    month_name, 
    year,
    CASE 
        WHEN MONTH(date) = 11 AND DAY(date) BETWEEN 20 AND 30 THEN 'Thanksgiving Period'
        WHEN MONTH(date) = 12 AND DAY(date) BETWEEN 15 AND 31 THEN 'Christmas Period'
        ELSE 'Regular Period'
    END AS holiday_period
FROM date
WHERE MONTH(date) IN (11, 12)
;

-- How can I prepare a customer-date combination for future sales analysis
SELECT 
    c.customer_code, 
    c.custmer_name, 
    c.customer_type, 
    d.date, 
    d.date_yy_mmm
FROM customers c
CROSS JOIN date d
WHERE d.date BETWEEN '2019-01-01' AND '2019-12-31'
LIMIT 30;


-- How can I count potential customer-date combinations by customer type and year
SELECT 
    c.customer_type, 
    d.year, 
    COUNT(*) AS combination_count
FROM customers c
CROSS JOIN date d
GROUP BY c.customer_type, d.year
ORDER BY d.year, c.customer_type;






