select * from customers;
select * from date;
select * from markets;
select * from products;
select * from transactions;


