-- Data Profiling and Quality Checks --
-- How many customers are in the dataset, and how are they distributed by customer type
SELECT customer_type, COUNT(*) AS customer_count, 
       ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS percentage
FROM customers
GROUP BY customer_type;

-- Are there any duplicate customer codes or names 
SELECT customer_code, custmer_name, COUNT(*) AS count
FROM customers
GROUP BY customer_code, custmer_name
HAVING count > 1;

-- Are there any missing or null values in the dataset
SELECT 
    SUM(CASE WHEN customer_code IS NULL THEN 1 ELSE 0 END) AS null_customer_code,
    SUM(CASE WHEN custmer_name IS NULL THEN 1 ELSE 0 END) AS null_custmer_name,
    SUM(CASE WHEN customer_type IS NULL THEN 1 ELSE 0 END) AS null_customer_type
FROM customers;

-- How many unique customer types exist, and what are they
SELECT DISTINCT customer_type
FROM customers;

-- Customer Segmentation --
-- How many customers have "Electricals" in their name, and what is their customer type distribution 
SELECT customer_type, COUNT(*) AS customer_count
FROM customers
WHERE custmer_name LIKE '%Electricals%'
GROUP BY customer_type;

-- Can customers be grouped by name patterns to identify potential business focus
SELECT 
    CASE 
        WHEN custmer_name LIKE '%Electricals%' THEN 'Electricals-Focused'
        ELSE 'General'
    END AS name_category,
    customer_type,
    COUNT(*) AS customer_count
FROM customers
GROUP BY name_category, customer_type;


-- Preparation for Future Analysis
-- Which customers might be key accounts based on their type (assuming future sales data)
SELECT customer_code, custmer_name, customer_type
FROM customers
ORDER BY customer_type, custmer_name;

-- How can I validate customer codes for consistency (e.g., length or format)
SELECT customer_code, custmer_name, LENGTH(customer_code) AS code_length
FROM customers
WHERE LENGTH(customer_code) != 6 OR customer_code NOT LIKE 'Cus%';

-- Business-Relevant Insights --
-- Are there any naming conventions that suggest regional or operational differences
SELECT 
    custmer_name,
    customer_type,
    CASE 
        WHEN custmer_name LIKE '%Stores%' THEN 'Store-Suffixed'
        ELSE 'Non-Store-Suffixed'
    END AS name_suffix
FROM customers
ORDER BY name_suffix, customer_type;

