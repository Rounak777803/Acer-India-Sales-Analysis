-- Data Profiling  --
-- What is the total number of markets and their distribution by zone
SELECT 
    zone, 
    COUNT(*) AS market_count
FROM markets
GROUP BY zone
WITH ROLLUP;

-- What are the unique markets and their codes
SELECT DISTINCT markets_code, markets_name
FROM markets
ORDER BY markets_code;

-- Are there any duplicate market names with different codes 
SELECT markets_name, COUNT(*) AS count
FROM markets
GROUP BY markets_name
HAVING count > 1;

-- Are there any missing or null values in the zone column
SELECT 
    COUNT(*) AS total_records,
    SUM(CASE WHEN zone IS NULL THEN 1 ELSE 0 END) AS null_zones
FROM markets;

-- Are all markets_code values unique
SELECT markets_code, COUNT(*) AS count
FROM markets
GROUP BY markets_code
HAVING count > 1;

-- Preparation for Time-Based and Relational Analysis --
-- How can I prepare a market-zone-date combination for future sales analysis
SELECT 
    m.markets_code, 
    m.markets_name, 
    m.zone, 
    d.date, 
    d.date_yy_mmm
FROM markets m
CROSS JOIN date d
WHERE d.date BETWEEN '2019-01-01' AND '2019-12-31'
LIMIT 10;

-- How many market-date combinations exist by zone and year
SELECT 
    m.zone, 
    d.year, 
    COUNT(*) AS combination_count
FROM markets m
CROSS JOIN date d
GROUP BY m.zone, d.year
ORDER BY d.year, m.zone;

-- Business-Relevant Insights --
-- Which zones have the most markets, and how might this impact sales strategy
SELECT 
    zone, 
    COUNT(*) AS market_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM markets WHERE zone IS NOT NULL), 2) AS zone_percentage
FROM markets
WHERE zone IS NOT NULL
GROUP BY zone
ORDER BY market_count DESC;

-- How can I identify markets without assigned zones for further investigation
SELECT markets_code, markets_name
FROM markets
WHERE zone IS NULL;

-- Integrating with Previous Datasets -- 
SELECT 
    c.customer_code, 
    c.custmer_name, 
    c.customer_type, 
    m.markets_code, 
    m.markets_name, 
    m.zone, 
    d.date, 
    d.date_yy_mmm
FROM customers c
CROSS JOIN markets m
CROSS JOIN date d
WHERE d.date BETWEEN '2019-06-01' AND '2019-06-30'
LIMIT 10;

